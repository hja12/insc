# AlipayShangJin
微信跳转到支付宝APP自动领取赏金红包脚本（Android起到引导作用）
不懂如何配置参数的加群：239326844
# 参数配置
**支付宝商家ID**
```
const shareId ='xxx';
```

**红包码Token**
```
const toKen ='xxx';
```

**红包码搜索码**
```
const hongbaoNum ='xxx';
```

